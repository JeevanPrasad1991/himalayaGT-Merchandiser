package com.cpm.xmlGetterSetter;

public class CallsGetterSetter {
	
	String key_id,store_id, total_calls, productive_calls;

	public String getKey_id() {
		return key_id;
	}

	public void setKey_id(String key_id) {
		this.key_id = key_id;
	}

	public String getStore_id() {
		return store_id;
	}

	public void setStore_id(String store_id) {
		this.store_id = store_id;
	}

	public String getTotal_calls() {
		return total_calls;
	}

	public void setTotal_calls(String total_calls) {
		this.total_calls = total_calls;
	}

	public String getProductive_calls() {
		return productive_calls;
	}

	public void setProductive_calls(String productive_calls) {
		this.productive_calls = productive_calls;
	}

}

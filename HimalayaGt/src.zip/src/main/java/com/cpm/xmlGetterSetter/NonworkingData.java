package com.cpm.xmlGetterSetter;

public class NonworkingData {
	
	String nonworkingtable;
	

	public String getNonworkingtable() {
		return nonworkingtable;
	}

	public void setNonworkingtable(String nonworkingtable) {
		this.nonworkingtable = nonworkingtable;
	}

}

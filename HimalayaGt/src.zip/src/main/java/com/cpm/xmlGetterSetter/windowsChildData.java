package com.cpm.xmlGetterSetter;

import java.util.ArrayList;

/**
 * Created by ashishc on 06-06-2016.
 */
public class windowsChildData {

   String Backsheet;
    String shelfStrip;

    public String getHeaderRefId() {
        return HeaderRefId;
    }

    public void setHeaderRefId(String headerRefId) {
        HeaderRefId = headerRefId;
    }

    String HeaderRefId;



    public String getPOG() {
        return POG;
    }

    public void setPOG(String POG) {
        this.POG = POG;
    }

    String POG;

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    String Image;


    String Statuschecklist;

    public String getChecklistWindows_cd() {
        return ChecklistWindows_cd;
    }

    public void setChecklistWindows_cd(String checklistWindows_cd) {
        ChecklistWindows_cd = checklistWindows_cd;
    }

    public String getStatuschecklist() {
        return Statuschecklist;
    }

    public void setStatuschecklist(String statuschecklist) {
        Statuschecklist = statuschecklist;
    }

    public String getChecklistCHECKLIST_ID() {
        return ChecklistCHECKLIST_ID;
    }

    public void setChecklistCHECKLIST_ID(String checklistCHECKLIST_ID) {
        ChecklistCHECKLIST_ID = checklistCHECKLIST_ID;
    }

    public String getChecklistCHECKLIST() {
        return ChecklistCHECKLIST;
    }

    public void setChecklistCHECKLIST(String checklistCHECKLIST) {
        ChecklistCHECKLIST = checklistCHECKLIST;
    }

    String ChecklistWindows_cd;
    String ChecklistCHECKLIST_ID;
    String ChecklistCHECKLIST;









    public String getShelfStrip() {
        return shelfStrip;
    }

    public void setShelfStrip(String shelfStrip) {
        this.shelfStrip = shelfStrip;
    }

    public String getBacksheet() {
        return Backsheet;
    }

    public void setBacksheet(String backsheet) {
        Backsheet = backsheet;
    }






    public String getWINDOW() {
        return WINDOW;
    }

    public void setWINDOW(String WINDOW) {
        this.WINDOW = WINDOW;
    }

    public String getWINDOW_CD() {
        return WINDOW_CD;
    }

    public void setWINDOW_CD(String WINDOW_CD) {
        this.WINDOW_CD = WINDOW_CD;
    }

    String WINDOW;
    String WINDOW_CD;



    String STORE_CD;

    public String getSTORE_CD() {
        return STORE_CD;
    }

    public void setSTORE_CD(String STORE_CD) {
        this.STORE_CD = STORE_CD;
    }

    public String getSTORE_TYPE_CD() {
        return STORE_TYPE_CD;
    }

    public void setSTORE_TYPE_CD(String STORE_TYPE_CD) {
        this.STORE_TYPE_CD = STORE_TYPE_CD;
    }

    String STORE_TYPE_CD;


String Present;
    String STATUS_CD;

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getSTATUS_CD() {
        return STATUS_CD;
    }

    public void setSTATUS_CD(String STATUS_CD) {
        this.STATUS_CD = STATUS_CD;
    }

    String STATUS;


    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String remarks) {
        Remarks = remarks;
    }

    String Remarks;

    public String getSTATE_CD() {
        return STATE_CD;
    }

    public void setSTATE_CD(String STATE_CD) {
        this.STATE_CD = STATE_CD;
    }

    String STATE_CD;














    public String getPresent() {
        return Present;
    }

    public void setPresent(String present) {
        Present = present;
    }
}

package com.cpm.xmlGetterSetter;

public class Sup_Performance {
	
	String supPerformanceTable;
	String mandays;
	String coverage;
	String merchandised;
	String compliance;
	public String getMandays() {
		return mandays;
	}
	public void setMandays(String mandays) {
		this.mandays = mandays;
	}
	public String getCoverage() {
		return coverage;
	}
	public void setCoverage(String coverage) {
		this.coverage = coverage;
	}
	public String getMerchandised() {
		return merchandised;
	}
	public void setMerchandised(String merchandised) {
		this.merchandised = merchandised;
	}
	public String getCompliance() {
		return compliance;
	}
	public void setCompliance(String compliance) {
		this.compliance = compliance;
	}
	public String getSupPerformanceTable() {
		return supPerformanceTable;
	}
	public void setSupPerformanceTable(String supPerformanceTable) {
		this.supPerformanceTable = supPerformanceTable;
	}
	
	

}

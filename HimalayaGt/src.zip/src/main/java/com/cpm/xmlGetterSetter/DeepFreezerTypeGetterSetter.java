package com.cpm.xmlGetterSetter;

public class DeepFreezerTypeGetterSetter {
	
	String fid;
	String deep_freezer;
	String freezer_type;
	String status;
	String remark;
	
	
	public String getFid() {
		return fid;
	}
	public void setFid(String fid) {
		this.fid = fid;
	}
	public String getDeep_freezer() {
		return deep_freezer;
	}
	public void setDeep_freezer(String deep_freezer) {
		this.deep_freezer = deep_freezer;
	}
	public String getFreezer_type() {
		return freezer_type;
	}
	public void setFreezer_type(String freezer_type) {
		this.freezer_type = freezer_type;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}

}

package com.cpm.xmlGetterSetter;

/**
 * Created by yadavendras on 14-03-2016.
 */
public class ChecklistInsertDataGetterSetter {

    String checklist_id, checklist, checklist_type, checklist_text, asset_cd;

    public String getChecklist_id() {
        return checklist_id;
    }

    public void setChecklist_id(String checklist_id) {
        this.checklist_id = checklist_id;
    }

    public String getChecklist() {
        return checklist;
    }

    public void setChecklist(String checklist) {
        this.checklist = checklist;
    }

    public String getChecklist_type() {
        return checklist_type;
    }

    public void setChecklist_type(String checklist_type) {
        this.checklist_type = checklist_type;
    }

    public String getChecklist_text() {
        return checklist_text;
    }


    public void setChecklist_text(String checklist_text) {
        this.checklist_text = checklist_text;
    }

    public String getAsset_cd() {
        return asset_cd;
    }

    public void setAsset_cd(String asset_cd) {
        this.asset_cd = asset_cd;
    }
}

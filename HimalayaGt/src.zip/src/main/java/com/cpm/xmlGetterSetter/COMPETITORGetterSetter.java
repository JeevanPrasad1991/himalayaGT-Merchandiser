package com.cpm.xmlGetterSetter;

/**
 * Created by ashishc on 29-08-2016.
 */
public class COMPETITORGetterSetter {



String COMPANY_CD;
   String COMPANY;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    String ID;
    public String getSpinnerExists() {
        return SpinnerExists;
    }

    public void setSpinnerExists(String spinnerExists) {
        SpinnerExists = spinnerExists;
    }

    String SpinnerExists;

    public String getSpinnerExists_CD() {
        return SpinnerExists_CD;
    }

    public void setSpinnerExists_CD(String spinnerExists_CD) {
        SpinnerExists_CD = spinnerExists_CD;
    }

    String SpinnerExists_CD;


    public String getEdText() {
        return EdText;
    }

    public void setEdText(String edText) {
        EdText = edText;
    }

    String EdText;



    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    String Image;
    public String getISCOMPETITOR() {
        return ISCOMPETITOR;
    }

    public void setISCOMPETITOR(String ISCOMPETITOR) {
        this.ISCOMPETITOR = ISCOMPETITOR;
    }

    public String getCOMPANY() {
        return COMPANY;
    }

    public void setCOMPANY(String COMPANY) {
        this.COMPANY = COMPANY;
    }

    public String getCOMPANY_CD() {
        return COMPANY_CD;
    }

    public void setCOMPANY_CD(String COMPANY_CD) {
        this.COMPANY_CD = COMPANY_CD;
    }

    String ISCOMPETITOR;
    String Camara;

    public String getCheckbox() {
        return Checkbox;
    }

    public void setCheckbox(String checkbox) {
        Checkbox = checkbox;
    }

    public String getCamara() {
        return Camara;
    }

    public void setCamara(String camara) {
        Camara = camara;
    }

    String Checkbox;







}

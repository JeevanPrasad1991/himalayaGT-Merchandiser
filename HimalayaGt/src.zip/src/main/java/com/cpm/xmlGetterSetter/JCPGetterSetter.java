package com.cpm.xmlGetterSetter;

import java.util.ArrayList;

public class JCPGetterSetter {

	ArrayList<String> storeid = new ArrayList<String>();
	ArrayList<String> storename = new ArrayList<String>();
	ArrayList<String> storeaddres = new ArrayList<String>();

	ArrayList<String> coverage_type = new ArrayList<String>();
	ArrayList<String> visitdate = new ArrayList<String>();
	ArrayList<String> storelatitude = new ArrayList<String>();
	ArrayList<String> storelongitude = new ArrayList<String>();
	ArrayList<String> status = new ArrayList<String>();
	ArrayList<String> checkout = new ArrayList<String>();

	ArrayList<String> CATEGORY_ID = new ArrayList<String>();
	ArrayList<String> KEY_ID = new ArrayList<String>();
	ArrayList<String> store_typeid = new ArrayList<String>();
	ArrayList<String> region_id = new ArrayList<String>();

	ArrayList<String> channel = new ArrayList<String>();
	ArrayList<String> classification = new ArrayList<String>();
	ArrayList<String> no_of_shelves = new ArrayList<String>();
	ArrayList<String> store_image = new ArrayList<String>();
	ArrayList<String> store_size = new ArrayList<String>();
	ArrayList<String> store_layout = new ArrayList<String>();
	ArrayList<String> key_account = new ArrayList<String>();
	
	ArrayList<String> contact_person = new ArrayList<String>();
	ArrayList<String> mobile = new ArrayList<String>();
	
	ArrayList<String> normal = new ArrayList<String>();
	public ArrayList<String> getContact_person() {
		return contact_person;
	}

	public void setContact_person(String contact_person) {
		this.contact_person.add(contact_person);
	}

	public ArrayList<String> getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.add(mobile);
	}

	public ArrayList<String> getNormal() {
		return normal;
	}

	public void setNormal(String normal) {
		this.normal.add(normal);
	}

	public ArrayList<String> getSpecial() {
		return special;
	}

	public void setSpecial(String special) {
		this.special.add(special);
	}

	ArrayList<String> special = new ArrayList<String>();

	public ArrayList<String> getKey_account() {
		return key_account;
	}

	public void setKey_account(String key_account) {
		this.key_account.add(key_account);
	}

	public ArrayList<String> getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel.add(channel);
	}

	public ArrayList<String> getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification.add(classification);
	}

	public ArrayList<String> getNo_of_shelves() {
		return no_of_shelves;
	}

	public void setNo_of_shelves(String no_of_shelves) {
		this.no_of_shelves.add(no_of_shelves);
	}

	public ArrayList<String> getStore_image() {
		return store_image;
	}

	public void setStore_image(String store_image) {
		this.store_image.add(store_image);
	}

	public ArrayList<String> getStore_size() {
		return store_size;
	}

	public void setStore_size(String store_size) {
		this.store_size.add(store_size);
	}

	public ArrayList<String> getStore_layout() {
		return store_layout;
	}

	public void setStore_layout(String store_layout) {
		this.store_layout.add(store_layout);
	}

	public ArrayList<String> getStore_typeid() {
		return store_typeid;
	}

	public void setStore_typeid(String store_typeid) {
		this.store_typeid.add(store_typeid);
	}

	public ArrayList<String> getRegion_id() {
		return region_id;
	}

	public void setRegion_id(String region_id) {
		this.region_id.add(region_id);
	}

	public ArrayList<String> getKEY_ID() {
		return KEY_ID;
	}

	public void setKEY_ID(String kEY_ID) {
		this.KEY_ID.add(kEY_ID);
	}

	public ArrayList<String> getStoreid() {
		return storeid;
	}

	public void setStoreid(String storeid) {
		this.storeid.add(storeid);
	}

	public ArrayList<String> getStorename() {
		return storename;
	}

	public void setStorename(String storename) {
		this.storename.add(storename);
	}

	public ArrayList<String> getStoreaddres() {
		return storeaddres;
	}

	public void setStoreaddres(String storeaddres) {
		this.storeaddres.add(storeaddres);
	}

	public ArrayList<String> getCoverage_type() {
		return coverage_type;
	}

	public void setCoverage_type(String coverage_type) {
		this.coverage_type.add(coverage_type);
	}

	public ArrayList<String> getVisitdate() {
		return visitdate;
	}

	public void setVisitdate(String visitdate) {
		this.visitdate.add(visitdate);
	}

	public ArrayList<String> getStorelatitude() {
		return storelatitude;
	}

	public void setStorelatitude(String storelatitude) {
		this.storelatitude.add(storelatitude);
	}

	public ArrayList<String> getStorelongitude() {
		return storelongitude;
	}

	public void setStorelongitude(String storelongitude) {
		this.storelongitude.add(storelongitude);
	}

	public ArrayList<String> getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status.add(status);
	}

	public ArrayList<String> getCheckOutStatus() {
		return checkout;
	}

	public void setCheckOutStatus(String status) {
		this.checkout.add(status);
	}

	public ArrayList<String> getCATEGORY_ID() {
		return CATEGORY_ID;
	}

	public void setCATEGORY_ID(String cATEGORY_ID) {
		CATEGORY_ID.add(cATEGORY_ID);
	}

}

package com.cpm.xmlGetterSetter;

public class FacingCompetitorGetterSetter {
	
	public String getStore_cd() {
		return store_cd;
	}

	public void setStore_cd(String store_cd) {
		this.store_cd = store_cd;
	}

	public String getCategory_cd() {
		return category_cd;
	}

	public void setCategory_cd(String category_cd) {
		this.category_cd = category_cd;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getMccaindf() {
		return mccaindf;
	}

	public void setMccaindf(String mccaindf) {
		this.mccaindf = mccaindf;
	}

	public String getStoredf() {
		return storedf;
	}

	public void setStoredf(String storedf) {
		this.storedf = storedf;
	}

	String store_cd, category, mccaindf, storedf, category_cd, brand, brand_cd;

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getBrand_cd() {
		return brand_cd;
	}

	public void setBrand_cd(String brand_cd) {
		this.brand_cd = brand_cd;
	}
}

package com.cpm.xmlGetterSetter;

public class FoodStoreInsertDataGetterSetter {
	
String brand_cd, brand,sku_cd, sku,as_per_meccain, actual_listed, packing_size, mccain_df, store_df, mtd_sales;
	
	

	public String getPacking_size() {
	return packing_size;
}

public void setPacking_size(String packing_size) {
	this.packing_size = packing_size;
}

public String getMccain_df() {
	return mccain_df;
}

public void setMccain_df(String mccain_df) {
	this.mccain_df = mccain_df;
}

public String getStore_df() {
	return store_df;
}

public void setStore_df(String store_df) {
	this.store_df = store_df;
}

public String getMtd_sales() {
	return mtd_sales;
}

public void setMtd_sales(String mtd_sales) {
	this.mtd_sales = mtd_sales;
}

	public String getBrand_cd() {
		return brand_cd;
	}

	public void setBrand_cd(String brand_cd) {
		this.brand_cd = brand_cd;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getAs_per_meccain() {
		return as_per_meccain;
	}

	public void setAs_per_meccain(String as_per_meccain) {
		this.as_per_meccain = as_per_meccain;
	}

	public String getActual_listed() {
		return actual_listed;
	}

	public void setActual_listed(String actual_listed) {
		this.actual_listed = actual_listed;
	}

	

	public String getSku_cd() {
		return sku_cd;
	}

	public void setSku_cd(String sku_cd) {
		this.sku_cd = sku_cd;
	}

}

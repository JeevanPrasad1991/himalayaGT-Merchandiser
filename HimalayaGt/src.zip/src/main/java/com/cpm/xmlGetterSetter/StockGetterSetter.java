package com.cpm.xmlGetterSetter;

public class StockGetterSetter {

	public String getCategory_type() {
		return category_type;
	}

	public void setCategory_type(String category_type) {
		this.category_type = category_type;
	}

	public String getAs_per_meccain() {
		return as_per_meccain;
	}

	public void setAs_per_meccain(String as_per_meccain) {
		this.as_per_meccain = as_per_meccain;
	}

	public String getActual_listed() {
		return actual_listed;
	}

	public void setActual_listed(String actual_listed) {
		this.actual_listed = actual_listed;
	}

	public String getClos_stock_cold_room() {
		return clos_stock_cold_room;
	}

	public void setClos_stock_cold_room(String clos_stock_cold_room) {
		this.clos_stock_cold_room = clos_stock_cold_room;
	}

	public String getClos_stock_meccaindf() {
		return clos_stock_meccaindf;
	}

	public void setClos_stock_meccaindf(String clos_stock_meccaindf) {
		this.clos_stock_meccaindf = clos_stock_meccaindf;
	}

	public String getClos_stock_storedf() {
		return clos_stock_storedf;
	}

	public void setClos_stock_storedf(String clos_stock_storedf) {
		this.clos_stock_storedf = clos_stock_storedf;
	}

	public String getBrand_cd() {
		return brand_cd;
	}

	public void setBrand_cd(String brand_cd) {
		this.brand_cd = brand_cd;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getSku_cd() {
		return sku_cd;
	}

	public void setSku_cd(String sku_cd) {
		this.sku_cd = sku_cd;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getOpen_stock_cold_room() {
		return open_stock_cold_room;
	}

	public void setOpen_stock_cold_room(String open_stock_cold_room) {
		this.open_stock_cold_room = open_stock_cold_room;
	}

	public String getOpen_stock_mccaindf() {
		return open_stock_mccaindf;
	}

	public void setOpen_stock_mccaindf(String open_stock_mccaindf) {
		this.open_stock_mccaindf = open_stock_mccaindf;
	}

	public String getTotalfacing_mccaindf() {
		return totalfacing_mccaindf;
	}

	public void setTotalfacing_mccaindf(String totalfacing_mccaindf) {
		this.totalfacing_mccaindf = totalfacing_mccaindf;
	}

	public String getOpen_stock_store_df() {
		return open_stock_store_df;
	}

	public void setOpen_stock_store_df(String open_stock_store_df) {
		this.open_stock_store_df = open_stock_store_df;
	}

	public String getTotal_facing_storedf() {
		return total_facing_storedf;
	}

	public void setTotal_facing_storedf(String total_facing_storedf) {
		this.total_facing_storedf = total_facing_storedf;
	}

	public String getMaterial_wellness() {
		return material_wellness;
	}

	public void setMaterial_wellness(String material_wellness) {
		this.material_wellness = material_wellness;
	}

	public String getMidday_stock() {
		return midday_stock;
	}

	public void setMidday_stock(String midday_stock) {
		this.midday_stock = midday_stock;
	}

	String brand_cd, brand,sku_cd, sku,category_type,as_per_meccain, actual_listed,open_stock_cold_room, open_stock_mccaindf, totalfacing_mccaindf, open_stock_store_df, total_facing_storedf, material_wellness,midday_stock,clos_stock_cold_room, clos_stock_meccaindf, clos_stock_storedf;
	
}

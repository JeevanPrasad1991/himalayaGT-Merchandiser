package com.cpm.xmlGetterSetter;

/**
 * Created by yadavendras on 26-08-2016.
 */
public class AnswerChecklistGetterSetter {

    String answer_cd, answer, checklist_cd;

    public String getAnswer_cd() {
        return answer_cd;
    }

    public void setAnswer_cd(String answer_cd) {
        this.answer_cd = answer_cd;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getChecklist_cd() {
        return checklist_cd;
    }

    public void setChecklist_cd(String checklist_cd) {
        this.checklist_cd = checklist_cd;
    }

}

package com.cpm.xmlGetterSetter;


public class StoreSignAgeGetterSetter {


    String remark;

    String name;

    String existSpinner;
    String Workingsppiner;
    String Image;

    String existSpinner_CD;

    public String getWorkingsppiner_CD() {
        return Workingsppiner_CD;
    }

    public void setWorkingsppiner_CD(String workingsppiner_CD) {
        Workingsppiner_CD = workingsppiner_CD;
    }

    public String getExistSpinner_CD() {
        return existSpinner_CD;
    }

    public void setExistSpinner_CD(String existSpinner_CD) {
        this.existSpinner_CD = existSpinner_CD;
    }

    String Workingsppiner_CD;


    public String getWorkingsppiner() {
        return Workingsppiner;
    }

    public void setWorkingsppiner(String workingsppiner) {
        Workingsppiner = workingsppiner;
    }

    public String getExistSpinner() {
        return existSpinner;
    }

    public void setExistSpinner(String existSpinner) {
        this.existSpinner = existSpinner;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }



    public String getContact() {
        return Contact;
    }

    public void setContact(String contact) {
        Contact = contact;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    String Contact;
    String Address;

    public String getSTORE_ID() {
        return STORE_ID;
    }

    public void setSTORE_ID(String STORE_ID) {
        this.STORE_ID = STORE_ID;
    }

    String STORE_ID;



    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    String Id;


    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


}

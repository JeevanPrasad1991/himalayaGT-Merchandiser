package com.cpm.xmlGetterSetter;

public class HeaderGetterSetter {
	
	public String getKeyId() {
		return keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	String keyId;

}

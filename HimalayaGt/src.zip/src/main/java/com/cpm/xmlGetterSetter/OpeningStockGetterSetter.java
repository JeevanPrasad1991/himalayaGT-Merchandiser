package com.cpm.xmlGetterSetter;

public class OpeningStockGetterSetter {
	
	String sku_cd, sku, brand_cd, brand, category_cd, category, mrp, category_seq, brand_seq, sku_seq;

	public String getSku_cd() {
		return sku_cd;
	}

	public void setSku_cd(String sku_cd) {
		this.sku_cd = sku_cd;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getBrand_cd() {
		return brand_cd;
	}

	public void setBrand_cd(String brand_cd) {
		this.brand_cd = brand_cd;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCategory_cd() {
		return category_cd;
	}

	public void setCategory_cd(String category_cd) {
		this.category_cd = category_cd;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getMrp() {
		return mrp;
	}

	public void setMrp(String mrp) {
		this.mrp = mrp;
	}

	public String getCategory_seq() {
		return category_seq;
	}

	public void setCategory_seq(String category_seq) {
		this.category_seq = category_seq;
	}

	public String getBrand_seq() {
		return brand_seq;
	}

	public void setBrand_seq(String brand_seq) {
		this.brand_seq = brand_seq;
	}

	public String getSku_seq() {
		return sku_seq;
	}

	public void setSku_seq(String sku_seq) {
		this.sku_seq = sku_seq;
	}

}

package com.cpm.xmlGetterSetter;

public class MiddayStockInsertData {
	
	public String getSku_cd() {
		return sku_cd;
	}

	public void setSku_cd(String sku_cd) {
		this.sku_cd = sku_cd;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getMidday_stock() {
		return midday_stock;
	}

	public void setMidday_stock(String midday_stock) {
		this.midday_stock = midday_stock;
	}

	String sku_cd, sku,midday_stock;

}

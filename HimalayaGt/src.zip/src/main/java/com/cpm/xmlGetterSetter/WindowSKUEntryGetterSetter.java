package com.cpm.xmlGetterSetter;

/**
 * Created by yadavendras on 30-08-2016.
 */
public class WindowSKUEntryGetterSetter {

    String category_cd, category, brand_cd, brand, sku_cd, sku, stock, onetosix, seventotwelve, abovethirteen;
    String visit_date;
    String username;
    String window_cd;
    String existOrnot;
    String window_image;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    String remark="";

    public String getStockabovethirteen() {
        return stockabovethirteen;
    }

    public void setStockabovethirteen(String stockabovethirteen) {
        this.stockabovethirteen = stockabovethirteen;
    }

    String stockabovethirteen;

    public String getStocksonetosix() {
        return stocksonetosix;
    }

    public void setStocksonetosix(String stocksonetosix) {
        this.stocksonetosix = stocksonetosix;
    }

    String stocksonetosix;


    public String getStore_cd() {
        return store_cd;
    }

    public void setStore_cd(String store_cd) {
        this.store_cd = store_cd;
    }

    public String getVisit_date() {
        return visit_date;
    }

    public void setVisit_date(String visit_date) {
        this.visit_date = visit_date;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getWindow_cd() {
        return window_cd;
    }

    public void setWindow_cd(String window_cd) {
        this.window_cd = window_cd;
    }

    public String getExistOrnot() {
        return existOrnot;
    }

    public void setExistOrnot(String existOrnot) {
        this.existOrnot = existOrnot;
    }

    public String getWindow_image() {
        return window_image;
    }

    public void setWindow_image(String window_image) {
        this.window_image = window_image;
    }

    String store_cd;


    public String getCategory_cd() {
        return category_cd;
    }

    public void setCategory_cd(String category_cd) {
        this.category_cd = category_cd;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getBrand_cd() {
        return brand_cd;
    }

    public void setBrand_cd(String brand_cd) {
        this.brand_cd = brand_cd;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSku_cd() {
        return sku_cd;
    }

    public void setSku_cd(String sku_cd) {
        this.sku_cd = sku_cd;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getOnetosix() {
        return onetosix;
    }

    public void setOnetosix(String onetosix) {
        this.onetosix = onetosix;
    }

    public String getSeventotwelve() {
        return seventotwelve;
    }

    public void setSeventotwelve(String seventotwelve) {
        this.seventotwelve = seventotwelve;
    }

    public String getAbovethirteen() {
        return abovethirteen;
    }

    public void setAbovethirteen(String abovethirteen) {
        this.abovethirteen = abovethirteen;
    }
}

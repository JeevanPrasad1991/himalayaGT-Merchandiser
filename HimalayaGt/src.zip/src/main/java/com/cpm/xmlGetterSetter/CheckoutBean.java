package com.cpm.xmlGetterSetter;


public class CheckoutBean {
	
	private String visitdate,time,latitude,longitude;
	
	
	public String getVisitDate() {
		return visitdate;
	}
	public void setVisitDate(String visitdate) {
		this.visitdate = visitdate;
	}
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time= time;
	}
	
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitide) {
		this.latitude = latitide;
	}
	
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
}

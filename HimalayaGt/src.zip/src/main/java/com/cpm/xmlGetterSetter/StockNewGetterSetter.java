package com.cpm.xmlGetterSetter;


public class StockNewGetterSetter {

   String openning_total_stock,opening_facing,stock_under45days,total_mid_stock_received,closing_stock,brand_cd, brand,sku_cd, sku, img_cam, visit_date;


    public String getCategory_image() {
        return category_image;
    }

    public void setCategory_image(String category_image) {
        this.category_image = category_image;
    }

    String  category_image="";
    String stockunder6="";
    String stockunder12="";
    String stockgreater13="";
    public String getStockgreater13() {
        return stockgreater13;
    }

    public void setStockgreater13(String stockgreater13) {
        this.stockgreater13 = stockgreater13;
    }

    public String getStockunder12() {
        return stockunder12;
    }

    public void setStockunder12(String stockunder12) {
        this.stockunder12 = stockunder12;
    }

    public String getStockunder6() {
        return stockunder6;
    }

    public void setStockunder6(String stockunder6) {
        this.stockunder6 = stockunder6;
    }





    public String getSTATE_CD() {
        return STATE_CD;
    }

    public void setSTATE_CD(String STATE_CD) {
        this.STATE_CD = STATE_CD;
    }

    String STATE_CD;


    public String getSTORE_TYPE_CD() {
        return STORE_TYPE_CD;
    }

    public void setSTORE_TYPE_CD(String STORE_TYPE_CD) {
        this.STORE_TYPE_CD = STORE_TYPE_CD;
    }

    String STORE_TYPE_CD;

    public String getCATEGORY_CD() {
        return CATEGORY_CD;
    }

    public void setCATEGORY_CD(String CATEGORY_CD) {
        this.CATEGORY_CD = CATEGORY_CD;
    }

    String CATEGORY_CD;


    public String getCOMPANY_CD() {
        return COMPANY_CD;
    }

    public void setCOMPANY_CD(String COMPANY_CD) {
        this.COMPANY_CD = COMPANY_CD;
    }

    String COMPANY_CD;


    public String getBRAND_SEQUENCE() {
        return BRAND_SEQUENCE;
    }

    public void setBRAND_SEQUENCE(String BRAND_SEQUENCE) {
        this.BRAND_SEQUENCE = BRAND_SEQUENCE;
    }

    String BRAND_SEQUENCE;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    String date;





    public String getOpenning_total_stock() {
        return openning_total_stock;
    }

    public void setOpenning_total_stock(String openning_total_stock) {
        this.openning_total_stock = openning_total_stock;
    }

    public String getOpening_facing() {
        return opening_facing;
    }

    public void setOpening_facing(String opening_facing) {
        this.opening_facing = opening_facing;
    }

    public String getStock_under45days() {
        return stock_under45days;
    }

    public void setStock_under45days(String stock_under45days) {
        this.stock_under45days = stock_under45days;
    }

    public String getTotal_mid_stock_received() {
        return total_mid_stock_received;
    }

    public void setTotal_mid_stock_received(String total_mid_stock_received) {
        this.total_mid_stock_received = total_mid_stock_received;
    }

    public String getClosing_stock() {
        return closing_stock;
    }

    public void setClosing_stock(String closing_stock) {
        this.closing_stock = closing_stock;
    }

    public String getBrand_cd() {
        return brand_cd;
    }

    public void setBrand_cd(String brand_cd) {
        this.brand_cd = brand_cd;
    }


    public String getSku_cd() {
        return sku_cd;
    }

    public void setSku_cd(String sku_cd) {
        this.sku_cd = sku_cd;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getImg_cam() {
        return img_cam;
    }

    public void setImg_cam(String img_cam) {
        this.img_cam = img_cam;
    }

    public String getVisit_date() {
        return visit_date;
    }

    public void setVisit_date(String visit_date) {
        this.visit_date = visit_date;
    }
}

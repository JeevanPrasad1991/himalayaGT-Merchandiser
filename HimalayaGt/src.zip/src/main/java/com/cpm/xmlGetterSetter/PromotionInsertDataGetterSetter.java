package com.cpm.xmlGetterSetter;

public class PromotionInsertDataGetterSetter {
	
	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getBrand_cd() {
		return brand_cd;
	}

	public void setBrand_cd(String brand_cd) {
		this.brand_cd = brand_cd;
	}

	public String getSku_cd() {
		return sku_cd;
	}

	public void setSku_cd(String sku_cd) {
		this.sku_cd = sku_cd;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getPromotion_txt() {
		return promotion_txt;
	}

	public void setPromotion_txt(String promotion_txt) {
		this.promotion_txt = promotion_txt;
	}

	public String getCategory_type() {
		return category_type;
	}

	public void setCategory_type(String category_type) {
		this.category_type = category_type;
	}

	public String getPresent() {
		return present;
	}

	public void setPresent(String present) {
		this.present = present;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	String brand,brand_cd,sku_cd, sku, promotion_txt, category_type, present, remark,pid,img;

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}
}

package com.cpm.xmlGetterSetter;

public class ClosingStockInsertDataGetterSetter {
	
	String brand_cd, brand,sku_cd, sku,clos_stock_cold_room, meccaindf, storedf;

	public String getBrand_cd() {
		return brand_cd;
	}

	public void setBrand_cd(String brand_cd) {
		this.brand_cd = brand_cd;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getClos_stock_cold_room() {
		return clos_stock_cold_room;
	}

	public void setClos_stock_cold_room(String clos_stock_cold_room) {
		this.clos_stock_cold_room = clos_stock_cold_room;
	}

	public String getMeccaindf() {
		return meccaindf;
	}

	public void setMeccaindf(String meccaindf) {
		this.meccaindf = meccaindf;
	}

	public String getStoredf() {
		return storedf;
	}

	public String getSku_cd() {
		return sku_cd;
	}

	public void setSku_cd(String sku_cd) {
		this.sku_cd = sku_cd;
	}

	public void setStoredf(String storedf) {
		this.storedf = storedf;
	}

}

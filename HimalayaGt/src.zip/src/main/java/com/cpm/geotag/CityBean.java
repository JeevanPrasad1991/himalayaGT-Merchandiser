package com.cpm.geotag;

public class CityBean {
	
	
	public String cityName;
	
	public String cityId;
	
	public void setCityName(String cityName)
	{
		
		this.cityName = cityName;
	}
	
	public void setCityId(String cityId)
	{
		
		this.cityId = cityId;
	}
	
	public String getCityName()
	{
		
		return cityName;
	}
	
	public String getCityId()
	{
		
		
		return cityId;
	}

}

package com.cpm.delegates;

public class TableBean {
	
	public static String getCategorymastertable() {
		return categorymastertable;
	}

	public static void setCategorymastertable(String categorymastertable) {
		TableBean.categorymastertable = categorymastertable;
	}

	public static String jcptable;	
	public static String skumastertable;
	public static String mappingavailtable;

	public static String getMappingavailablitytable() {
		return mappingavailablitytable;
	}

	public static void setMappingavailablitytable(String mappingavailablitytable) {
		TableBean.mappingavailablitytable = mappingavailablitytable;
	}

	public static String mappingavailablitytable;

	public static String getMappingposmtable() {
		return mappingposmtable;
	}

	public static void setMappingposmtable(String mappingposmtable) {
		TableBean.mappingposmtable = mappingposmtable;
	}

	public static String mappingposmtable;

	public static String mappingpromotable;
	public static String mappingassettable;
	public static String deepfreezertable;
	public static String assetmastertable;

	public static String getCompanymastertable() {
		return Companymastertable;
	}

	public static void setCompanymastertable(String companymastertable) {
		Companymastertable = companymastertable;
	}

	public static String Companymastertable;

	public static String nonworkingtable;
	public static String categorymastertable;
	public static String performancetable;
	
	public static String closingcoldtable;

	public static String companytable;

	public static String questiontable;

	public static String brandtable;

	public static String asset_checklist_table;

	public static String mapping_asset_checklist_table;

	public static String getClosingcoldtable() {
		return closingcoldtable;
	}

	public static void setClosingcoldtable(String closingcoldtable) {
		TableBean.closingcoldtable = closingcoldtable;
	}

	public static String getPerformancetable() {
		return performancetable;
	}

	public static void setPerformancetable(String performancetable) {
		TableBean.performancetable = performancetable;
	}

	public static String getNonworkingtable() {
		return nonworkingtable;
	}

	public static void setNonworkingtable(String nonworkingtable) {
		TableBean.nonworkingtable = nonworkingtable;
	}

	public static String getDeepfreezertable() {
		return deepfreezertable;
	}

	public static void setDeepfreezertable(String deepfreezertable) {
		TableBean.deepfreezertable = deepfreezertable;
	}

	public static String table_mappingwindowchecklist;
	public static String getTable_mappingwindowchecklist() {
		return table_mappingwindowchecklist;
	}

	public static void setTable_mappingwindowchecklist(String table_mappingwindowchecklist) {
		TableBean.table_mappingwindowchecklist = table_mappingwindowchecklist;
	}

	public static String getAssetmastertable() {
		return assetmastertable;
	}

	public static void setAssetmastertable(String assetmastertable) {
		TableBean.assetmastertable = assetmastertable;
	}

	public static String table_windowchecklistanswer;
	public static String getTable_windowchecklistanswer() {
		return table_windowchecklistanswer;
	}

	public static void setTable_windowchecklistanswer(String table_windowchecklistanswer) {
		TableBean.table_windowchecklistanswer = table_windowchecklistanswer;
	}





	public static String getMappingavailtable() {
		return mappingavailtable;
	}

	public static void setMappingavailtable(String mappingavailtable) {
		TableBean.mappingavailtable = mappingavailtable;
	}

	public static String getSkumastertable() {
		return skumastertable;
	}

	public static void setSkumastertable(String skumastertable) {
		TableBean.skumastertable = skumastertable;
	}

	public static String getjcptable() {
		return jcptable;
	}

	public static void setjcptable(String jcptable) {
		TableBean.jcptable = jcptable;
	}
	
	public static String getMappingpromotable() {
		return mappingpromotable;
	}

	public static void setMappingpromotable(String mappingpromotable) {
		TableBean.mappingpromotable = mappingpromotable;
	}
	
	public static String getMappingassettable() {
		return mappingassettable;
	}

	public static void setMappingassettable(String mappingassettable) {
		TableBean.mappingassettable = mappingassettable;
	}

	public static String getCompanytable() {
		return companytable;
	}

	public static void setCompanytable(String companytable) {
		TableBean.companytable = companytable;
	}

	public static String getQuestiontable() {
		return questiontable;
	}

	public static void setQuestiontable(String questiontable) {
		TableBean.questiontable = questiontable;
	}

	public static String getBrandtable() {
		return brandtable;
	}

	public static void setBrandtable(String brandtable) {
		TableBean.brandtable = brandtable;
	}

	public static String getAsset_checklist_table() {
		return asset_checklist_table;
	}

	public static void setAsset_checklist_table(String asset_checklist_table) {
		TableBean.asset_checklist_table = asset_checklist_table;
	}

	public static String getMapping_asset_checklist_table() {
		return mapping_asset_checklist_table;
	}

	public static void setMapping_asset_checklist_table(String mapping_asset_checklist_table) {
		TableBean.mapping_asset_checklist_table = mapping_asset_checklist_table;
	}

	
/*public static String merchandisetable;

public static String storeTable;
public static String nonWorkingTable;
public static String distributorTable;

public static String journeyplan;
public static String designation;

public static String tableDeviation;
public static String secWindow;
public static String supPerform;
public static String supMerchandiser;*/

/*public static String getSecWindow() {
	return secWindow;
}

public static void setSecWindow(String secWindow) {
	TableBean.secWindow = secWindow;
}

public static String getSupMerchandiser() {
	return supMerchandiser;
}

public static void setSupMerchandiser(String supMerchandiser) {
	TableBean.supMerchandiser = supMerchandiser;
}

public static String getSupPerform() {
	return supPerform;
}

public static void setSupPerform(String supPerform) {
	TableBean.supPerform = supPerform;
}

public static String getTableDeviation() {
	return tableDeviation;
}

public static void setTableDeviation(String tableDeviation) {
	TableBean.tableDeviation = tableDeviation;
}

public static String getJourneyplan() {
	return journeyplan;
}

public static void setJourneyplan(String journeyplan) {
	TableBean.journeyplan = journeyplan;
}

public static String getDesignation() {
	return designation;
}

public static void setDesignation(String designation) {
	TableBean.designation = designation;
}

public static String getDistributorTable() {
	return distributorTable;
}

public static void setDistributorTable(String distributorTable) {
	TableBean.distributorTable = distributorTable;
}

public static String getNonWorkingTable() {
	return nonWorkingTable;
}

public static void setNonWorkingTable(String nonWorkingTable) {
	TableBean.nonWorkingTable = nonWorkingTable;
}

public static String getStoreTable() {
	return storeTable;
}

public static void setStoreTable(String storeTable) {
	TableBean.storeTable = storeTable;
}

public static String getMerchandisetable() {
	return merchandisetable;
}

public static void setMerchandisetable(String merchandisetable) {
	TableBean.merchandisetable = merchandisetable;
}*/



}
